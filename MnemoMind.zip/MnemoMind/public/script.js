/* Mnemo client — fixed for Replit proxy at /mnemo */

/* STORAGE */
const STORAGE_KEY = "mnemo_memories_v1";

function loadMemories() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.warn("Corrupt localStorage, clearing.", e);
    localStorage.removeItem(STORAGE_KEY);
    return [];
  }
}

function saveMemoriesToStorage(memories) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(memories));
}

/* PARSING — tolerant to many LLM output shapes */
function extractTextFromResponse(data) {
  if (!data) return "";
  if (typeof data === "string") return data;

  if (data.choices && data.choices[0]) {
    if (data.choices[0].message && data.choices[0].message.content)
      return data.choices[0].message.content;
    if (data.choices[0].text) return data.choices[0].text;
  }

  if (data.result && typeof data.result === "string") return data.result;
  if (data.content && typeof data.content === "string") return data.content;

  return JSON.stringify(data, null, 2);
}

function parseMemoryContent(text) {
  const lines = text
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean);

  let title = "";
  let keyDetails = [];
  let mnemonic = "";
  let tips = "";
  let categories = [];

  const combined = lines.join("\n");

  const titleMatch = combined.match(
    /(?:\*\*Memory Title\*\*|Memory Title:|Title:)\s*(.+)/i,
  );
  if (titleMatch) title = titleMatch[1].trim();

  const detailsMatch = combined.match(
    /(?:\*\*Key Details\*\*|Key Details:|Key Facts:)([\s\S]*?)(?:\n\n|$)/i,
  );
  if (detailsMatch) {
    const block = detailsMatch[1].trim();
    keyDetails = block
      .split(/[\n\r]+/)
      .map((l) => l.replace(/^[-•*]\s*/, "").trim())
      .filter(Boolean);
  }

  const mnMatch = combined.match(
    /(?:\*\*Mnemo Association\*\*|\*\*Mnemonic\*\*|Mnemonic:|Mnemo Association:)([\s\S]*?)(?:\n\n|$)/i,
  );
  if (mnMatch) mnemonic = mnMatch[1].trim();

  const tipsMatch = combined.match(
    /(?:\*\*Additional Tips\*\*|\*\*Tips\*\*|Tips:|Reflection:)([\s\S]*?)(?:\n\n|$)/i,
  );
  if (tipsMatch) tips = tipsMatch[1].trim();

  const catMatch = combined.match(
    /(?:Category:|Categories:|Tag:|Tags:)\s*(.+)/i,
  );
  if (catMatch)
    categories = catMatch[1]
      .split(/[;,]+/)
      .map((s) => s.trim())
      .filter(Boolean);

  if (!title && lines.length)
    title = lines[0].replace(/^[-•*#\s]+/, "").slice(0, 60);
  if (!keyDetails.length && lines.length > 1)
    keyDetails = lines
      .slice(1, 4)
      .map((l) => l.replace(/^[-•*]\s*/, "").trim());
  if (!mnemonic) {
    const short = lines.find(
      (l) =>
        l.length < 100 &&
        /imagine|picture|visual|remember|mnemonic|imagine/i.test(l),
    );
    if (short) mnemonic = short;
  }
  if (!tips) {
    const tip = lines.find((l) => /tip|remember|next time|when/i.test(l));
    if (tip) tips = tip;
  }
  if (!categories.length) {
    const lower = combined.toLowerCase();
    if (/(friend|social|date|party)/.test(lower)) categories.push("Social");
    if (/(work|meeting|project|backend|frontend)/.test(lower))
      categories.push("Work");
    if (/(learn|study|class|lecture|exam)/.test(lower))
      categories.push("Learning");
    if (/(health|doctor|exercise|allerg)/.test(lower))
      categories.push("Health");
  }

  return { title, keyDetails, mnemonic, tips, categories, rawText: text };
}

/* UI helpers */
function escapeHtml(s = "") {
  const d = document.createElement("div");
  d.textContent = s;
  return d.innerHTML;
}

function createMemoryCard(memory, index, isSaved = false) {
  const card = document.createElement("div");
  card.className = "memory-card";

  const now = memory.timestamp ? new Date(memory.timestamp) : null;
  const timeHtml = now
    ? `<div style="font-size:12px;color:var(--muted);margin-bottom:8px">${now.toLocaleString()}</div>`
    : "";

  let html = `${timeHtml}<div style="display:flex;justify-content:space-between;align-items:flex-start">`;
  html += `<div style="flex:1"><div class="memory-title">${escapeHtml(memory.title)}</div>`;

  if (memory.keyDetails && memory.keyDetails.length) {
    html += `<div class="memory-section key-details"><div class="section-label">Key Details</div><ul>`;
    html += memory.keyDetails.map((d) => `<li>${escapeHtml(d)}</li>`).join("");
    html += `</ul></div>`;
  }

  if (memory.mnemonic) {
    html += `<div class="memory-section"><div class="section-label">Mnemonic</div><div class="mnemonic-box">${escapeHtml(memory.mnemonic)}</div></div>`;
  }

  if (memory.tips) {
    html += `<div class="memory-section"><div class="section-label">Reflection & Tips</div><div class="tips-list">${escapeHtml(memory.tips)}</div></div>`;
  }

  if (memory.categories && memory.categories.length) {
    html += `<div style="margin-top:8px">`;
    memory.categories.forEach((c) => {
      html += `<span class="tag">${escapeHtml(c)}</span>`;
    });
    html += `</div>`;
  }

  html += `</div>`; // left

  html += `<div style="margin-left:12px">`;
  if (isSaved) {
    html += `<button class="delete-btn" title="Delete" data-index="${index}">×</button>`;
  } else {
    html += `<button class="action-btn save-btn" id="save-now">Save</button>`;
    html += `<div style="height:8px"></div>`;
    html += `<button class="action-btn" id="clear-now">Clear</button>`;
  }
  html += `</div></div>`; // end row

  card.innerHTML = html;

  if (!isSaved) {
    const saveBtn = card.querySelector("#save-now");
    const clearBtn = card.querySelector("#clear-now");
    if (saveBtn)
      saveBtn.addEventListener("click", () => saveCurrentMemory(memory));
    if (clearBtn)
      clearBtn.addEventListener("click", () => {
        document.getElementById("output").innerHTML = "";
        currentMemory = null;
      });
  } else {
    const del = card.querySelector(".delete-btn");
    if (del)
      del.addEventListener("click", (e) => {
        const idx = Number(e.currentTarget.dataset.index);
        deleteMemory(idx);
      });
  }

  return card;
}

/* Save memory */
function saveCurrentMemory(mem) {
  const toSave = mem || currentMemory;
  if (!toSave) return;
  const memories = loadMemories();
  memories.unshift({ ...toSave, timestamp: Date.now() });
  saveMemoriesToStorage(memories);
  renderSavedMemories();
  const output = document.getElementById("output");
  output.innerHTML = `<div class="memory-card"><div style="color:var(--muted)">Saved ✓</div></div>`;
  setTimeout(() => {
    output.innerHTML = "";
    currentMemory = null;
  }, 900);
}

/* Delete memory */
function deleteMemory(index) {
  if (!confirm("Delete this memory?")) return;
  const arr = loadMemories();
  arr.splice(index, 1);
  saveMemoriesToStorage(arr);
  renderSavedMemories();
}

/* Render saved memories */
function renderSavedMemories() {
  const container = document.getElementById("saved-memories-list");
  const memories = loadMemories();
  container.innerHTML = "";
  if (!memories.length) {
    container.innerHTML = `<div class="empty-state"><div class="empty-icon">💭</div><p>No saved memories yet. Elevate one!</p></div>`;
    return;
  }
  memories.forEach((m, i) => {
    container.appendChild(createMemoryCard(m, i, true));
  });
}

/* UI state */
let currentMemory = null;
const outputEl = document.getElementById("output");
const inputEl = document.getElementById("input");
const elevateBtn = document.getElementById("elevate-btn");
const clearBtn = document.getElementById("clear-btn");
const exportBtn = document.getElementById("export-btn");
const clearAllBtn = document.getElementById("clear-all-btn");

/* NETWORK — call /mnemo proxy */
async function callMnemoAPI(text) {
  const res = await fetch("/mnemo", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text }), // <-- FIX: send { text } not model+messages
  });

  if (!res.ok) {
    let errText;
    try {
      errText = await res.json();
    } catch (e) {
      errText = { error: res.statusText };
    }
    throw new Error(errText.error || errText.message || `Server ${res.status}`);
  }

  const data = await res.json();
  return extractTextFromResponse(data);
}

/* Elevate button handler */
elevateBtn.addEventListener("click", async () => {
  const txt = inputEl.value.trim();
  if (!txt) {
    outputEl.innerHTML = `<div class="memory-card"><div style="color:var(--muted)">Please enter a short moment first.</div></div>`;
    return;
  }
  outputEl.innerHTML = `<div class="memory-card"><div style="color:var(--muted)">Elevating your memory…</div></div>`;
  currentMemory = null;

  try {
    const responseText = await callMnemoAPI(txt);
    const parsed = parseMemoryContent(responseText);
    currentMemory = parsed;
    outputEl.innerHTML = "";
    outputEl.appendChild(createMemoryCard(parsed, 0, false));
    inputEl.value = "";
  } catch (err) {
    console.error(err);
    outputEl.innerHTML = `<div class="memory-card"><div style="color:#ffb4b4">Error: ${escapeHtml(err.message || err.toString())}</div></div>`;
  }
});

/* Ctrl+Enter shortcut */
inputEl.addEventListener("keydown", (e) => {
  if (e.ctrlKey && e.key === "Enter") elevateBtn.click();
});

/* Clear input */
if (clearBtn)
  clearBtn.addEventListener("click", () => {
    inputEl.value = "";
    outputEl.innerHTML = "";
    currentMemory = null;
  });

/* Export JSON */
if (exportBtn)
  exportBtn.addEventListener("click", () => {
    const mem = loadMemories();
    const blob = new Blob([JSON.stringify(mem, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "mnemos.json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  });

/* Clear all saved */
if (clearAllBtn)
  clearAllBtn.addEventListener("click", () => {
    if (!confirm("Clear all saved memories? This cannot be undone.")) return;
    localStorage.removeItem(STORAGE_KEY);
    renderSavedMemories();
  });

/* Initialize */
renderSavedMemories();

/* --- cursor particles --- */
(function initParticles() {
  const canvas = document.getElementById("cursorParticles");
  const ctx = canvas.getContext("2d");
  let w = (canvas.width = innerWidth);
  let h = (canvas.height = innerHeight);
  const particles = [];

  window.addEventListener("resize", () => {
    w = canvas.width = innerWidth;
    h = canvas.height = innerHeight;
  });

  window.addEventListener("pointermove", (e) => {
    for (let i = 0; i < 2; i++) {
      particles.push({
        x: e.clientX + (Math.random() - 0.5) * 10,
        y: e.clientY + (Math.random() - 0.5) * 10,
        r: Math.random() * 3 + 1,
        vx: (Math.random() - 0.5) * 0.6,
        vy: (Math.random() - 0.5) * 0.6 - 0.2,
        life: 60 + Math.random() * 30,
      });
    }
  });

  function frame() {
    ctx.clearRect(0, 0, w, h);
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.life--;
      ctx.beginPath();
      ctx.fillStyle = `rgba(90,160,255,${Math.max(0, p.life / 90)})`;
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
      if (p.life <= 0) particles.splice(i, 1);
    }
    requestAnimationFrame(frame);
  }
  frame();
})();
