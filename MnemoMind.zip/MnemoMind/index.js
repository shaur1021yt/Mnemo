import express from "express";
import fetch from "node-fetch"; // or built-in fetch if using Node 18+
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());

/* Robust parser for Mnemo structured output */
function parseMnemoText(text) {
  const titleMatch = text.match(/Memory Title:\s*(.+)/i);
  const title = titleMatch ? titleMatch[1].trim() : "Untitled Memory";

  const keyDetailsMatch = text.match(
    /Key Details:\s*([\s\S]*?)(?:\n[A-Z][a-zA-Z ]*?:|$)/i,
  );
  const keyDetails = keyDetailsMatch
    ? keyDetailsMatch[1]
        .split(/\n/)
        .map((line) => line.replace(/^[-•\s]+/, "").trim())
        .filter(Boolean)
    : ["No details"];

  const mnemonicMatch = text.match(
    /Mnemonic:\s*([\s\S]*?)(?:\n[A-Z][a-zA-Z ]*?:|$)/i,
  );
  const mnemonic = mnemonicMatch ? mnemonicMatch[1].trim() : "";

  const tipsMatch = text.match(/Tips:\s*([\s\S]*?)(?:\n[A-Z][a-zA-Z ]*?:|$)/i);
  const tips = tipsMatch ? tipsMatch[1].trim() : "";

  const categoriesMatch = text.match(/Categories:\s*([\s\S]*?)(?:\n|$)/i);
  const categories = categoriesMatch
    ? categoriesMatch[1].split(/[,;]+/).map((s) => s.trim())
    : [];

  return { title, keyDetails, mnemonic, tips, categories, rawText: text };
}

/* Mnemo endpoint */
app.post("/mnemo", async (req, res) => {
  const { text } = req.body;
  if (!text) return res.status(400).json({ error: "Text is required" });

  try {
    const apiKey = process.env.GROQ_API_KEY;
    if (!apiKey) return res.status(500).json({ error: "GROQ_API_KEY not set" });

    const response = await fetch(
      "https://api.groq.com/openai/v1/chat/completions",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "llama-3.3-70b-versatile",
          messages: [
            {
              role: "system",
              content: `You are Mnemo, an AI that creates detailed memory objects from the user's text. STRICTLY fill in all fields with real content based on the user's input. 

Return EXACTLY in this format (no placeholders, no extra text):

Memory Title: [a short descriptive title]
Key Details:
- [2-5 important facts or points derived from the user's input]
Mnemonic: [a vivid mnemonic or memorable phrase]
Tips: [optional reflection or actionable tip based on the memory]
Categories: [1-3 relevant tags like Work, Personal, Learning, Health, Social, Creative]`,
            },
            { role: "user", content: text },
          ],
          temperature: 0.2,
          max_tokens: 800,
        }),
      },
    );

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Groq API error ${response.status}: ${errText}`);
    }

    const data = await response.json();

    const rawText =
      data?.choices?.[0]?.message?.content?.trim() ||
      data?.result?.trim() ||
      "";

    if (!rawText) {
      return res.json({
        title: "Untitled Memory",
        keyDetails: ["No details"],
        mnemonic: "",
        tips: "",
        categories: [],
        rawText: text,
      });
    }

    const memoryObj = parseMnemoText(rawText);
    res.json(memoryObj);
  } catch (err) {
    console.error("Mnemo API error:", err);
    res.status(500).json({
      error: err.message,
      memory: {
        title: "Untitled Memory",
        keyDetails: ["No details"],
        mnemonic: "",
        tips: "",
        categories: [],
        rawText: text,
      },
    });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () =>
  console.log(`Mnemo server running on http://0.0.0.0:${PORT}`),
);
