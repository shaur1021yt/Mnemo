# Mnemo

**A minimalist web app that transforms ordinary text into insightful memories using Groq's LLM API**

## Overview
Mnemo is a hackathon project built with Node.js and Express on the backend, with vanilla HTML, CSS, and JavaScript on the frontend. It takes ordinary daily notes from users and uses the Groq LLM API (llama-3.3-70b-versatile model) to transform them into meaningful, insightful memories.

## Project Structure
- `index.js` - Express server with API proxy
- `package.json` - Node.js dependencies
- `public/` - Frontend assets
  - `index.html` - Main HTML structure
  - `script.js` - Client-side JavaScript
  - `style.css` - Modern, minimal styling with gradient theme

## Features
- Node.js Express backend to avoid CORS issues
- Professional dark theme (#0d0d0d) with gold accents (#C8A951)
- Clean, centered layout (max-width 700px)
- Text area for input with keyboard shortcut (Ctrl+Enter)
- Structured memory cards with:
  - Bold memory titles
  - Bullet-point key details
  - Highlighted mnemonic boxes
  - Reflection & tips section
  - Category tags
- LocalStorage integration for saving memories
- Scrollable saved memories list
- Delete individual memories or clear all
- Smooth animations and hover effects
- Secure API key management via Replit Secrets
- XSS protection with safe text rendering

## Setup
1. Add your Groq API key as a Replit Secret: `GROQ_API_KEY`
2. Run `npm install` to install dependencies
3. Run `npm start` to start the server
4. The app runs on port 5000

## System Prompt
Structured format that generates:
- Memory Title
- Key Details (3-5 bullet points)
- Mnemonic (creative memory device)
- Tips (reflection and actionable advice)
- Categories (relevant tags)

## Technology Stack
- Backend: Node.js with Express
- Frontend: Vanilla HTML5, CSS3, JavaScript (ES6+)
- API: Groq (llama-3.3-70b-versatile model)
- Deployment: Replit with environment secrets

## Recent Changes
- 2025-11-08: Complete UI overhaul with dark theme and gold accents for hackathon judging
- 2025-11-08: Added localStorage memory persistence and saved memories list
- 2025-11-08: Implemented structured memory cards with sections and category tags
- 2025-11-08: Enhanced system prompt for consistent structured output
- 2025-11-08: Fixed Tips parsing bug to capture inline content
- 2025-11-08: Updated to llama-3.3-70b-versatile model (llama3-70b-8192 was deprecated)
- 2025-11-08: Fixed XSS vulnerability by using textContent instead of innerHTML
- 2025-11-08: Refactored to Node.js/Express architecture with backend proxy
- 2025-11-08: Added Replit Secrets integration for API key management
- 2025-11-08: Initial project creation with static files
